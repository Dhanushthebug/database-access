# SAR-imaging
Synthetic Aperture Radar Imaging

几种传统雷达成像算法，将数据DAT_01.001放在scene01文件夹下，下载链接：

链接：https://pan.baidu.com/s/198PaXLU8v8BFwQ-tG4sLHw 
提取码：8ia7 

![](SAR_CSA.jpg)
